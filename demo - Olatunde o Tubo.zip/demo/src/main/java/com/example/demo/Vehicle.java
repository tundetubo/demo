package com.example.demo;

import java.sql.Date;


public class Vehicle {
	
	private String firstName;
	private String lastName;
	String testType;
	Date testDate;
	
	public Vehicle(){
		super();
	}
	
  public Vehicle(String firstName, String lastName, String testType, Date testDate) {
	  
	  this.firstName = firstName;
	  this.lastName = lastName;
	  this.testType = testType;
	  this.testDate = testDate;
	  
	  
  }

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getTestType() {
	return testType;
}

public void setTestType(String testType) {
	this.testType = testType;
}

public Date getTestDate() {
	return testDate;
}

public void setTestDate(Date testDate) {
	this.testDate = testDate;
}
  
  
}
